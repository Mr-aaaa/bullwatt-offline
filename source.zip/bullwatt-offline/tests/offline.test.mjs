import test from 'node:test';
import assert from 'node:assert/strict';
import { ControlPoint, LatestPower, normalizePower } from '../offline/control.mjs';
import { sample, summary, csv, tcx, validateBackup, compactReport, heartZone } from '../offline/session.mjs';

const packet = (...bytes) => new DataView(Uint8Array.from(bytes).buffer);

test('heart zones use the configured maximum, with no zone for missing data', () => {
  assert.equal(heartZone(99, 200), 'easy');
  assert.equal(heartZone(100, 200), 'moderate');
  assert.equal(heartZone(140, 200), 'aerobic');
  assert.equal(heartZone(170, 200), 'high');
  assert.equal(heartZone(122, null), null);
  assert.equal(heartZone(null, 200), null);
});

test('summary splits a sample crossing a 30-second boundary and preserves missing readings', () => {
  const ride = makeSession();
  const start = Date.parse(ride.startedAt);
  for (let i = 1; i <= 29; i++) sample(ride, start + i * 1000, 1, { power: 0 });
  sample(ride, start + 31000, 2, { power: 60, heartRate: 120, cadence: 75 });
  const report = compactReport(ride);
  assert.deepEqual(report.trend, [[0, 30, 2, 120, 75], [30, 1, 60, 120, 75]]);
  assert.equal(report.metrics.power_w.max, 60);
  assert.equal(report.metrics.heart_rate_bpm.recorded_s, 2);
  assert.equal(report.metrics.power_w.recorded_s, 31);
  assert.ok(JSON.stringify(report).length < csv(ride).length);
});

test('normalizes to device grid, clamps and rejects blank/negative input', () => {
  const range = { min: 20, max: 603, step: 5 };
  assert.equal(normalizePower('143', range), 145);
  assert.equal(normalizePower('900', range), 600);
  assert.throws(() => normalizePower('', range));
  assert.throws(() => normalizePower(-1, range));
});

test('new rides count only positive-power time while recording coasting and missing data', () => {
  const ride = { ...makeSession(), durationMode: 'positive-power', recordedSeconds: 0 };
  const start = Date.parse(ride.startedAt);
  sample(ride, start + 1000, 1, { power: 0 });
  sample(ride, start + 3000, 2, { power: 150, heartRate: 120 });
  sample(ride, start + 4000, 1, { power: null, heartRate: 125 });
  sample(ride, start + 5000, 1, { power: -2 });
  assert.equal(ride.activeSeconds, 2);
  assert.equal(ride.recordedSeconds, 5);
  assert.equal(ride.samples.length, 4);
  assert.equal(ride.samples.at(-1).elapsedSeconds, 5);
  assert.match(tcx(ride), /<TotalTimeSeconds>2.000/);
  const compact = compactReport(ride);
  assert.equal(compact.active_s, 2);
  assert.equal(compact.recorded_s, 5);
  assert.equal(compact.columns[0], 'recorded_start_s');
  assert.deepEqual(validateBackup({version: 1, sessions: [ride]}), [ride]);
});

test('control waits for the matching indication and rejects device errors', async () => {
  let point;
  point = new ControlPoint(async bytes => {
    point.receive(packet(128, 0, 1));
    queueMicrotask(() => point.receive(packet(128, bytes[0], 3)));
  });
  await assert.rejects(point.send([5, 0, 0]), /参数/);
});

test('timeout invalidates the control point to prevent late acknowledgments', async () => {
  const point = new ControlPoint(async () => {}, 5);
  await assert.rejects(point.send([5]), /超时/);
  point.receive(packet(128, 5, 1));
  await assert.rejects(point.send([5]), /重新连接/);
});

test('power changes merge and a pause replaces pending high power', async () => {
  const writes = [];
  const releases = [];
  const queue = new LatestPower(watts => new Promise(resolve => {
    writes.push(watts);
    releases.push(resolve);
  }));
  const done = queue.set(100);
  queue.set(150);
  queue.set(200);
  queue.set(20);
  releases.shift()();
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(writes, [100, 20]);
  releases.shift()();
  await done;
});

const makeSession = () => ({
  id: 's', schemaVersion: 1, name: '自由训练', status: 'completed',
  startedAt: '2026-11-14T00:00:00.000Z', endedAt: '2026-11-14T00:00:04.000Z',
  samples: [], events: [], activeSeconds: 0,
});
test('distinguishes zero watts, missing heart rate and suspended time', () => {
  const ride = makeSession();
  const start = Date.parse(ride.startedAt);
  sample(ride, start + 1000, 1, { power: 0, heartRate: null });
  sample(ride, start + 3000, 2, { power: 150, heartRate: 120 });
  assert.equal(sample(ride, start + 9000, 6, { power: 150 }), false);
  assert.equal(summary(ride).power.mean, 100);
  assert.equal(summary(ride).heartRate.mean, 120);
  assert.equal(ride.activeSeconds, 3);
  assert.match(csv(ride), /,0,,,,/);
  assert.match(tcx(ride), /<Watts>0<\/Watts>/);
  assert.equal((tcx(ride).match(/<HeartRateBpm>/g) || []).length, 1);
  assert.deepEqual(validateBackup({version: 1, sessions: [ride]}), [ride]);
  assert.throws(() => validateBackup({version: 1, sessions: [{...ride, activeSeconds: -1}]}));
});
