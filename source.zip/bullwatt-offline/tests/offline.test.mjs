import test from 'node:test';
import assert from 'node:assert/strict';
import { ControlPoint, LatestPower, normalizePower } from '../offline/control.mjs';
import { sample, summary, csv, tcx, validateBackup } from '../offline/session.mjs';

const packet = (...bytes) => new DataView(Uint8Array.from(bytes).buffer);

test('normalizes to device grid, clamps and rejects blank/negative input', () => {
  const range = { min: 20, max: 603, step: 5 };
  assert.equal(normalizePower('143', range), 145);
  assert.equal(normalizePower('900', range), 600);
  assert.throws(() => normalizePower('', range));
  assert.throws(() => normalizePower(-1, range));
});

test('control waits for the matching indication and rejects device errors', async () => {
  let point;
  point = new ControlPoint(async bytes => {
    point.receive(packet(128, 0, 1));
    queueMicrotask(() => point.receive(packet(128, bytes[0], 3)));
  });
  await assert.rejects(point.send([5, 0, 0]), /参数/);
});

test('timeout invalidates the control point to prevent late acknowledgments', async () => {
  const point = new ControlPoint(async () => {}, 5);
  await assert.rejects(point.send([5]), /超时/);
  point.receive(packet(128, 5, 1));
  await assert.rejects(point.send([5]), /重新连接/);
});

test('power changes merge and a pause replaces pending high power', async () => {
  const writes = [];
  const releases = [];
  const queue = new LatestPower(watts => new Promise(resolve => {
    writes.push(watts);
    releases.push(resolve);
  }));
  const done = queue.set(100);
  queue.set(150);
  queue.set(200);
  queue.set(20);
  releases.shift()();
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(writes, [100, 20]);
  releases.shift()();
  await done;
});

const makeSession = () => ({
  id: 's', schemaVersion: 1, name: '自由训练', status: 'completed',
  startedAt: '2026-11-14T00:00:00.000Z', endedAt: '2026-11-14T00:00:04.000Z',
  samples: [], events: [], activeSeconds: 0,
});
test('distinguishes zero watts, missing heart rate and suspended time', () => {
  const ride = makeSession();
  const start = Date.parse(ride.startedAt);
  sample(ride, start + 1000, 1, { power: 0, heartRate: null });
  sample(ride, start + 3000, 2, { power: 150, heartRate: 120 });
  assert.equal(sample(ride, start + 9000, 6, { power: 150 }), false);
  assert.equal(summary(ride).power.mean, 100);
  assert.equal(summary(ride).heartRate.mean, 120);
  assert.equal(ride.activeSeconds, 3);
  assert.match(csv(ride), /,0,,,,/);
  assert.match(tcx(ride), /<Watts>0<\/Watts>/);
  assert.equal((tcx(ride).match(/<HeartRateBpm>/g) || []).length, 1);
  assert.deepEqual(validateBackup({version: 1, sessions: [ride]}), [ride]);
  assert.throws(() => validateBackup({version: 1, sessions: [{...ride, activeSeconds: -1}]}));
});
