import test from 'node:test';
import assert from 'node:assert/strict';
import { activateUpdate } from '../offline/update.mjs';

test('explicit update waits for new worker activation without touching stored rides', async () => {
  const worker = new EventTarget();
  worker.state = 'installed';
  worker.postMessage = message => {
    assert.deepEqual(message, { type: 'ACTIVATE_UPDATE' });
    queueMicrotask(() => {
      worker.state = 'activated';
      worker.dispatchEvent(new Event('statechange'));
    });
  };
  let checked = false;
  await activateUpdate({
    update: async () => { checked = true; },
    waiting: worker,
  });
  assert.equal(checked, true);
  assert.equal(worker.state, 'activated');
});

test('failed cache installation does not report an update as ready', async () => {
  const worker = new EventTarget();
  worker.state = 'installing';
  const result = activateUpdate({
    update: async () => {},
    installing: worker,
  });
  queueMicrotask(() => {
    worker.state = 'redundant';
    worker.dispatchEvent(new Event('statechange'));
  });
  await assert.rejects(result, /缓存失败/);
});
