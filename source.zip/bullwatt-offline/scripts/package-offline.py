"""Create distributable zip archives without including Git metadata or local data."""
from pathlib import Path
import json
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile

root = Path(__file__).resolve().parent.parent
dist = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root / "dist"


def tracked(directory):
    result = subprocess.check_output(["git", "-C", str(directory), "ls-files", "-z"])
    return [directory / name.decode("utf-8") for name in result.split(b"\0") if name]


auuki = root / "dependencies" / "auuki"
inventory = root / "offline-source-files.json"
if inventory.is_file():
    items = {root / name for name in json.loads(inventory.read_text(encoding="utf-8"))}
else:
    items = set(tracked(root) + tracked(auuki))
for directory in ("offline", "scripts", "tests"):
    items.update((root / directory).glob("*"))
items.update(root / name for name in (".github/workflows/offline-pages.yml", "docs/offline-quickstart-zh.md"))
paths = sorted(path.relative_to(root) for path in items if path.is_file() and not path.is_symlink() and path != inventory)
with ZipFile(dist / "source.zip", "w", ZIP_DEFLATED) as archive:
    for path in paths:
        archive.write(root / path, Path("bullwatt-offline") / path)
    archive.writestr("bullwatt-offline/offline-source-files.json", json.dumps([path.as_posix() for path in paths]))

if len(sys.argv) > 2:
    target = Path(sys.argv[2]).resolve()
    target.mkdir(parents=True, exist_ok=True)
    from shutil import copyfile
    copyfile(dist / "source.zip", target / "BullWatt-离线版源码.zip")
    with ZipFile(target / "BullWatt-安卓离线试用.zip", "w", ZIP_DEFLATED) as archive:
        for path in sorted(dist.rglob("*")):
            if path.is_file():
                archive.write(path, Path("site") / path.relative_to(dist))
        archive.write(root / "docs/offline-quickstart-zh.md", "安卓试用说明.md")
print("Packaged source and static website")
