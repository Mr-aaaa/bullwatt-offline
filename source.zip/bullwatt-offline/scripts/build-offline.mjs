import { mkdir, readFile, writeFile, copyFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, join } from 'node:path';

const root = fileURLToPath(new URL('..', import.meta.url));
const out = resolve(process.argv[2] ?? join(root, 'dist'));
const files = new Map();
const imports = /^\s*import\s+(?:[^'";]+?\s+from\s*)?['"]([^'"]+)['"]/gm;

async function copyModule(path) {
  if (files.has(path)) return;
  const code = await readFile(join(root, path), 'utf8');
  files.set(path, code);
  for (const match of code.matchAll(imports)) {
    if (!match[1].startsWith('.')) throw new Error('Unexpected external import: ' + match[1]);
    const dependency = new URL(match[1], 'https://build.invalid/' + path).pathname.slice(1);
    await copyModule(dependency);
  }
}
await copyModule('offline/app.mjs');
for (const name of ['index.html', 'styles.css', 'manifest.webmanifest']) {
  files.set('offline/' + name, await readFile(join(root, 'offline', name), 'utf8'));
}
for (const name of ['assets/android-chrome-192x192.png', 'assets/android-chrome-512x512.png']) {
  files.set(name, await readFile(join(root, name)));
}
const flatten = path => path.replace(/^offline\//, '');
const relocate = (path, data) => path.startsWith('offline/') && typeof data === 'string'
  ? data.replaceAll('../dependencies/', './dependencies/').replaceAll('../assets/', './assets/').replace('../LICENSE', './LICENSE')
  : data;
const hash = createHash('sha256');
const worker = await readFile(join(root, 'offline/sw.js'), 'utf8');
hash.update(worker);
for (const [path, data] of files) {
  const name = flatten(path);
  const contents = relocate(path, data);
  hash.update(name).update(contents);
  const destination = join(out, name);
  await mkdir(dirname(destination), { recursive: true });
  await writeFile(destination, contents);
}
const version = hash.digest('hex').slice(0, 16);
const assets = [...files.keys()].map(path => './' + flatten(path)).sort();
const sw = worker.replace("const version = 'development-v1';", 'const version = ' + JSON.stringify(version) + ';')
  .replace(/const relativeAssets = \[[\s\S]*?\];/, 'const relativeAssets = ' + JSON.stringify(assets) + ';');
await writeFile(join(out, 'sw.js'), sw);
await writeFile(join(out, '.nojekyll'), '');
await copyFile(join(root, 'LICENSE'), join(out, 'LICENSE'));
await copyFile(join(root, 'dependencies/auuki/LICENSE.txt'), join(out, 'LICENSE-Auuki.txt'));
console.log('Built ' + assets.length + ' precached resources, ' + version + ', in ' + out);
